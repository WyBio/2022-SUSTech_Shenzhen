path=getwd()
setwd(path) # set your own path 
source('MainFun.R')
count = 2:10
K_Asso_T_Value = 1:10 * 1 * 10 ^ -4
K_Asso_T_Value = append(K_Asso_T_Value,count * 1 * 10 ^ -3)
K_Asso_T_Value = append(K_Asso_T_Value,count * 1 * 10 ^ -2)
K_Asso_T_Value = append(K_Asso_T_Value,count * 1 * 10 ^ -1) 

K_Asso_BT_Value = 1:10 * 1 * 10 ^ -4
K_Asso_BT_Value = append(K_Asso_BT_Value,count * 1 * 10 ^ -3)
K_Asso_BT_Value = append(K_Asso_BT_Value,count * 1 * 10 ^ -2)
K_Asso_BT_Value = append(K_Asso_BT_Value,count * 1 * 10 ^ -1)


ratio1 = matrix(nrow=37,ncol=37) # Br_Indi / I
ratio2 = matrix(nrow=37,ncol=37) # Br_Indi / Br_Trp



for (count1 in 1:37) { 
  for (count2 in 1:37){
    ans = Cal(K_Asso_T_Value[count1],K_Asso_BT_Value[count2])
    ratio1[38-count2,count1] = ans[1]
    ratio2[38-count2,count1] = ans[2]
  }
}

print("yes")

saveRDS(ratio1,file="D:\Amber\igem\finalversion from Wu\FinalV4\FinalV3\Data\ratio1.RDS")
saveRDS(ratio2,file="D:\Amber\igem\finalversion from Wu\FinalV4\FinalV3\Data\ratio2.RDS")

path = getwd()
setwd(path)
library(pheatmap)
ratio1 <- readRDS("") # set up by your own
ratio2 <- readRDS("")
log_data1 <-log10(ratio1) 
colnames(log_data1) <- paste("Col", 1:37)
rownames(log_data1) <- paste("Row", 1:37)
pheatmap(log_data1,
         cluster_cols = FALSE,  
         cluster_rows = FALSE,
         
         main = "Ratio between Br-Indi / Br-Trp",
         
         labels_col = c(10^(-4),10^(-3),10^(-2),10^(-1),1),
         labels_row = c(1,10^(-1),10^(-2),10^(-3),10^(-4)),
        
         
         fontsize_row = 12,
         fontsize_col = 12,
         angle_col = 0)  

legend_breaks = c(-2, 2.5, 6)
legend_labels = c("Low", "Medium", "High")



log_data2 <-log10(ratio2) 
colnames(log_data2) <- paste("Col", 1:37)
rownames(log_data2) <- paste("Row", 1:37)
pheatmap(log_data2,
         cluster_cols = FALSE, 
         cluster_rows = FALSE,
         
         main = "Ratio between Br-Indi / I" ,
         labels_col = c(10^(-4),10^(-3),10^(-2),10^(-1),1),
         labels_row = c(1,10^(-1),10^(-2),10^(-3),10^(-4)),
         
         fontsize_row = 12,
         fontsize_col = 12,
         angle_col = 0)



