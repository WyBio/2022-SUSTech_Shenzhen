
library("deSolve")
Cal <- function(K_Asso_T_Value,K_Asso_BT_Value){
  ## MODELING PART
  library("deSolve")
  ## MODELING PART
  model <- function (t, x, params) {
    # Variant
    Trp <- x[1] # trp concentration
    Br_Trp <- x[2] # 6-Br-trp concentration
    mRNA_TrpRe <- x[3] # mRNA of Trp-Repressor
    TrpRe <- x[4] #  protein of Trp-Repressor
    TrpRe2 <- x[5] # Trp-Repressor bipolymer
    TrpRe2_T <- x[6] # binary compound of Trp-Repressor bipolymer and Trp
    TrpRe2_BT <- x[7] # binary compound of Trp-Repressor bipolymer and 6-Br-trp
    mRNA_TLF <- x[8] # mRNA of  tnaA-FL-FMO
    TLF <- x[9] # protein of  tnaA-FL-FMO
    Indo <- x[10] # Indoxyl concentration
    Br_Indo <- x[11] # 6-Br-trp Indoxyl concentration
    I <- x[12] # Indigo concentration
    Br_Indi <- x[13] # Br-Indican concentration
    TP <- x[14] # Tyrian purple concentration
    
    
    # Key parameter
    K_DegM <- params["K_DegM"] # Degradation rate of mRNA
    K_DegP <- params["K_DegP"] # Degradation rate of protein
    V_Br <- params["V_Br"] # Vmax of fre-sttH
    K_Br <- params["K_Br"] # Michaelis-Menten constant of fre-sttH
    DNA_TrpRe <- 12 # Trp-Repressor plasmid copy number
    K_TC1 <- params["K_TC1"] # Transcription rate of Trp-Repressor
    K_TL1 <- params["K_TL1"] # Translation rate of TrP-Repressor
    K_Di <- params["K_Di"] # Trp-Repressor dimerizing rate
    K_Sepe1 <- params["K_Sepe1"] # Separation rate of Trp-Repressor bipolymer
    K_Asso_T <- params["K_Asso_T"] # Association rate of Trp-Repressor bipolymer and Trp
    K_Asso_BT <- params["K_Asso_BT"] # Association rate of Trp-Repressor bipolymer and 6-Br-trp
    K_Sepe2 <- params["K_Sepe2"] # Separation rate of binary compound
    Trp0 <- 60
    Br_Trp0 <- 60
    DNA_TLF <- 20 # tnaA-FL-FMO plasmid copy number
    K_hill <- params["K_hill"] # Hill function constant of tnaA-FL-FMO
    n = 2 # Hill function order
    K_TC2 <- params["K_TC2"] # Transcription rate of tnaA-FL-FMO
    K_TL2 <- params["K_TL2"] # Translation rate of tnaA-FL-FMO
    V_TLF <- params["V_TLF"] # Vmax of tnaA-FL-FMO
    K_TLF1 <- params["K_TLF1"] # Michaelis-Menten constant of tnaA-FL-FMO
    K_TLF2 <- params["K_TLF2"] # Michaelis-Menten constant of tnaA-FL-FMO
    V_UGT <- params["V_UGT"] # Vmax of UGT
    K_UGT <- params["K_UGT"] # Michaelis-Menten constant of UGT
    K_02 <- params["K_02"] # oxygen reaction rate with Indoxyl and 6-Br-trp Indoxyl
    
    
    # Equation
    dTrpdt <- -V_Br * Trp / (Trp + K_Br) - V_TLF * Trp * TLF / (K_TLF1 + Trp)
    dBr_Trpdt <-V_Br * Trp / (Trp + K_Br) -V_TLF * Br_Trp * TLF / (K_TLF2 + Br_Trp) 
    dmRNA_TrpRedt <- K_TC1 * DNA_TrpRe - K_DegM * mRNA_TrpRe
    dTrpRedt <- K_TL1 * mRNA_TrpRe - K_DegP * TrpRe -  K_Di * TrpRe ^ 2 + K_Sepe1 * TrpRe2
    dTrpRe2dt <- K_Di * TrpRe ^ 2 - K_Sepe1 * TrpRe2 - K_Asso_T * TrpRe2 * Trp^2 / (Trp^2+Trp0^2) - K_Asso_BT * TrpRe2 * Br_Trp^2/(Br_Trp^2+Br_Trp0^2)+ K_Sepe2 * TrpRe2_T + K_Sepe2 * TrpRe2_BT
    dTrpRe2_Tdt <- K_Asso_T * TrpRe2 * Trp^2 / (Trp^2+Trp0^2) - K_Sepe2 * TrpRe2_T
    dTrpRe2_BTdt <- K_Asso_BT * TrpRe2 * Br_Trp^2/(Br_Trp^2+Br_Trp0^2) - K_Sepe2 * TrpRe2_BT
    dmRNA_TLFdt <- K_TC2 * DNA_TLF / (1 + ((TrpRe2_T + TrpRe2_BT) / K_hill) ^ n) - K_DegM * mRNA_TLF
    dTLFdt <- K_TL2 * mRNA_TLF - K_DegP * TLF
    dIndodt = V_TLF * Trp * TLF / (K_TLF1 + Trp) - K_02 * Indo ^ 2
    dBr_Indodt = V_TLF * Br_Trp * TLF / (K_TLF2 + Br_Trp) -  K_02 * Br_Indo ^ 2 -V_UGT * Br_Indo / (K_UGT + Br_Indo)
    
    dIdt = K_02 * Indo ^ 2
    dBr_Indidt = V_UGT * Br_Indo / (K_UGT + Br_Indo)
    dTPdt = K_02 * Br_Indo ^ 2
    
    
    
    dxdt <-c(dTrpdt,dBr_Trpdt,dmRNA_TrpRedt,dTrpRedt,dTrpRe2dt,dTrpRe2_Tdt,dTrpRe2_BTdt,dmRNA_TLFdt,dTLFdt,dIndodt,dBr_Indodt,dIdt,dBr_Indidt,dTPdt)
    list(dxdt)
  }
  
  
  params <- c(K_DegM = 5.1986,K_DegP = 0.33862,V_Br = 7.08778 * 10 ^ 2,K_Br = 4.060915*10^3,K_TC1 = 0.358,K_TL1 = 7.28,
              K_Di = 0.01,K_Sepe1 =0.392, K_Asso_T = K_Asso_T_Value, K_Asso_BT = K_Asso_BT_Value,K_Sepe2 = 0.6,
              K_hill=0.05,K_TC2=0.096,K_TL2=6.53 ,V_TLF = 8.72 ,K_TLF1 = 2500,K_TLF2 = 1000,V_UGT = 1 * 10 ^ 2,K_UGT = 1000,K_02 = 1 * 10 ^ -7)
  
  
  xstart <-
    c(Trp = 2.5 * 10 ^ 3,Br_Trp = 0,mRNA_TrpRe = 0,TrpRe = 0,TrpRe2 = 0,TrpRe2_T =0, TrpRe2_BT=0,mRNA_TLF=0,TLF=0,
      Indo=0,Br_Indo=0,I=0,Br_Indi=0,TP=0)
  
  times <- seq(from = 0, to = 200, by = 0.1)
  out <- ode(
    func = model,
    y = xstart,
    times = times,
    parms = params
  )
  out.df <- as.data.frame(out)
  Br_Indi = out.df[14]
  I = out.df[13]
  Br_Trp = out.df[3]
  Indo = out.df[11]
  
  
  ratio1 = Br_Indi[2001,] / Br_Trp[2001,] # 代表底物Br_Trp 生成情况，越大越好
  ratio2 = ratio2 = Br_Indi[2001,] / (I[2001,]+Indo[2001,]) # 代表靛蓝生成情况，越小越好
  ratio = c(ratio1,ratio2)
  
  return(ratio)
}


