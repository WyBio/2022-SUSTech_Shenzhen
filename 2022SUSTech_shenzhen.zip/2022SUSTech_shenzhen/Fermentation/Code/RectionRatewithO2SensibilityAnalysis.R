r <- c(908846.15,890957,8910.828,892.217,90.347,10.09,1.731,0.487)  #-10~-3
ratio <- log(r)
O2<- c(1:8)
r3 <- cbind(O2,ratio)
r4 <- data.frame(r3)
ggplot(data=r4, aes(x=O2, y=ratio))+
  geom_line(color='steelblue',size=2)+
  geom_point(size=4)+
  labs(title='                     TP/Br-Indi changes with k_O2',x='k_O2(Oxygen reaction rate with Indoxyl and 6-Br-trp Indoxyl)',y='ratio=log(TP/Br-Indi)')+
  theme_light()
  # scale_x_discrete(
  #   labels = c("1"="10^-10","2"="10^-9", "3"="10^-8", "4"="10^-7","5"="10^-6","6"="10^-5","7"="10^-4","8"="10^-3")
  # )

