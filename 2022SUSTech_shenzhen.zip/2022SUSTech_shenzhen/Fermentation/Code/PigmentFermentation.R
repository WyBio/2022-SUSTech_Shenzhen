library("deSolve")
## MODELING PART
model <- function (t, x, params) {
  ##  Variant
  
  # reaction 1
  Trp <- x[1] # trp concentration
  Br_Trp <- x[2] # 6-Br-trp concentration
  # reaction 2
  mRNA_TrpR <- x[3] # mRNA of Trp-Repressor
  TrpR <- x[4] #  protein of Trp-Repressor
  TrpR2 <- x[5] # Trp-Repressor bipolymer
  # reaction 3
  TrpR2_T <- x[6] # binary compound of Trp-Repressor bipolymer and Trp
  TrpR2_BT <- x[7] # binary compound of Trp-Repressor bipolymer and 6-Br-trp
  # reaction 4
  mRNA_TLF <- x[8] # mRNA of  tnaA-FL-FMO
  TLF <- x[9] # protein of  tnaA-FL-FMO
  # reaction 5
  I <- x[10] # Indigo concentration
  Br_Indo <- x[11] # 6-Br-trp Indoxyl concentration
  # reaction 6
  Br_Indi <- x[12] # Br-Indican concentration
  TP <- x[13]
  
  # Key parameter
  K_DegM <- params["K_DegM"] # Degradation rate of mRNA
  K_DegP <- params["K_DegP"] # Degradation rate of protein
  # reaction 1
  V_Br <- params["V_Br"] # Vmax of fre-sttH
  K_Br <- params["K_Br"] # Michaelis-Menten constant of fre-sttH
  DNA_TrpR <- 12 # Trp-Repressor plasmid copy number
  # reaction 2
  K_TC1 <- params["K_TC1"] # Transcription rate of Trp-Repressor
  K_TL1 <- params["K_TL1"] # Translation rate of TrP-Repressor
  K_Di <- params["K_Di"] # Trp-Repressor dimerizing rate
  K_Sepe1 <- params["K_Sepe1"] # Separation rate of Trp-Repressor bipolymer
  # reaction 3
  K_Asso_T <- params["K_Asso_T"] # Association rate of Trp-Repressor bipolymer and Trp
  K_Asso_BT <- params["K_Asso_BT"] # Association rate of Trp-Repressor bipolymer and 6-Br-trp
  K_Sepe2 <- params["K_Sepe2"] # Separation rate of binary compound
  Trp0 <- 60
  Br_Trp0 <- 60
  # reaction 4
  DNA_TLF <- 20 # tnaA-FL-FMO plasmid copy number
  K_hill <- params["K_hill"] # Hill function constant of tnaA-FL-FMO
  n = 2 # Hill function order
  K_TC2 <- params["K_TC2"] # Transcription rate of tnaA-FL-FMO
  K_TL2 <- params["K_TL2"] # Translation rate of tnaA-FL-FMO
  # reaction 5
  V_TLF <- params["V_TLF"] # Vmax of tnaA-FL-FMO
  K_TLF1 <- params["K_TLF1"] # Michaelis-Menten constant of tnaA-FL-FMO
  K_TLF2 <- params["K_TLF2"] # Michaelis-Menten constant of tnaA-FL-FMO
  # reaction 6
  V_UGT <- params["V_UGT"] # Vmax of UGT
  K_UGT <- params["K_UGT"] # Michaelis-Menten constant of UGT
  K_02 <- params["K_02"] # oxygen reaction rate with Indoxyl and 6-Br-trp Indoxyl
  
  
  # Equation
  
  # reaction 1
  dTrpdt <- -V_Br*Trp/(Trp+K_Br)-V_TLF*Trp*TLF/(K_TLF1+Trp)
  dBr_Trpdt <- V_Br*Trp/(Trp+K_Br)-V_TLF*Br_Trp*TLF/(K_TLF2+Br_Trp) 
  # reaction 2
  dmRNA_TrpRdt <- K_TC1*DNA_TrpR-K_DegM*mRNA_TrpR
  dTrpRdt <- K_TL1*mRNA_TrpR-K_DegP*TrpR-K_Di*TrpR^2+K_Sepe1*TrpR2
  dTrpR2dt <- K_Di*TrpR^2-K_Sepe1*TrpR2-K_Asso_T*TrpR2*Trp^2/(Trp^2+Trp0^2)-K_Asso_BT*TrpR2*Br_Trp^2/(Br_Trp^2+Br_Trp0^2)+K_Sepe2*TrpR2_T+K_Sepe2*TrpR2_BT
  # reaction 3
  dTrpR2_Tdt <- K_Asso_T*TrpR2*Trp^2/(Trp^2+Trp0^2)-K_Sepe2*TrpR2_T
  dTrpR2_BTdt <- K_Asso_BT*TrpR2*Br_Trp^2/(Br_Trp^2+Br_Trp0^2)-K_Sepe2*TrpR2_BT
  # reaction 4
  dmRNA_TLFdt <- K_TC2*DNA_TLF/(1+((TrpR2_T+TrpR2_BT)/K_hill)^n)-K_DegM*mRNA_TLF
  dTLFdt <- K_TL2*mRNA_TLF-K_DegP*TLF
  # reaction 5
  dIdt <- V_TLF*Trp*TLF/(K_TLF1+Trp)
  dBr_Indodt = V_TLF * Br_Trp * TLF / (K_TLF2 + Br_Trp) -  K_02 * Br_Indo ^ 2 -V_UGT * Br_Indo / (K_UGT + Br_Indo)
  # reaction 6
  dBr_Indidt = V_UGT * Br_Indo / (K_UGT + Br_Indo)
  dTPdt = K_02 * Br_Indo ^ 2
  
  
  
  dxdt <-c(dTrpdt,dBr_Trpdt,dmRNA_TrpRdt,dTrpRdt,dTrpR2dt,dTrpR2_Tdt,dTrpR2_BTdt,dmRNA_TLFdt,dTLFdt,dIdt,dBr_Indodt,dBr_Indidt,dTPdt)
  list(dxdt)
}


params <- c(K_DegM=5.1986, K_DegP=0.33862, 
            V_Br=7.08778*10^2, K_Br=4.060915*10^3,  # reaction 1
            K_TC1=0.358, K_TL1 =7.28,K_Di=0.01, K_Sepe1=0.392, # reaction 2
            K_Asso_T=6*10^-1, K_Asso_BT=1*10^-3, K_Sepe2=0.6, # reaction 3
            K_hill=0.05, K_TC2=0.56, K_TL2=6.53, # reaction 4
            V_TLF=4.72, K_TLF1=2500, K_TLF2=1000, # reaction 5
            V_UGT=1*10^2, K_UGT=1000, K_02=1*10^-10) # reaction 6


xstart <-
  c(Trp=2.5*10^3, Br_Trp=0, mRNA_TrpR=0, TrpR=0, TrpR2=0, TrpR2_T=0, TrpR2_BT=0, mRNA_TLF=0, TLF=0, I=0, Br_Indo=0, Br_Indi=0, TP=0)

times <- seq(from = 0, to = 200, by = 0.1)
out <- ode(
  func = model,
  y = xstart,
  times = times,
  parms = params
)
out.df <- as.data.frame(out)

library("ggplot2")
library("tidyr")

## This part is for plot

#1. Trp, Br_Trp
df <- gather(out.df, key = Protein, value = Amount,
             c("Trp", "Br_Trp"))

ggplot(df, aes(
  x = time,
  y = Amount,
  group = Protein,
  colour = Protein
)) +
  geom_line(size = 1) +
  labs(title='                   Changes of Trp & Br-Trp',x='Time(h)',y='Amount (uM)')+
  theme_light()+
  theme(legend.position = c(0.8,0.82))


#2. TLF, TrpR, TrpR2, TrpR2_T, TrpR2_BT
df <- gather(out.df, key = Protein, value = Amount,
             c("TLF","TrpR", "TrpR2","TrpR2_BT","TrpR2_T"))

ggplot(df, aes(
  x = time,
  y = Amount,
  group = Protein,
  colour = Protein
)) +
  geom_line(size = 1) +
  labs(title='  Changes of relevant amount during the reaction',x='Time(h)',y='Amount (uM)') +
  theme_light()+
  theme(legend.position = c(0.13,0.77))



#3. Trp, Br_Trp, I, Br_Indo, Br_Indi
df <- gather(out.df, key = Protein, value = Amount,
             c("I","Br_Indo","Br_Indi","TP"))

ggplot(df, aes(
  x = time,
  y = Amount,
  group = Protein,
  colour = Protein
)) +
  geom_line(size = 1) +
  labs(title='            Final production of the reaction',x='Time(h)',y='Amount (uM)')+
  theme_light()+
  theme(legend.position = c(0.13,0.77))

